# Tumaco Ruta: generar el APK
1. Crea un repositorio en github.com (gratis) y sube TODO el contenido de esta carpeta (incluida la carpeta oculta .github).
2. Ve a la pestaña Actions -> "Build APK" -> Run workflow (también corre solo al subir archivos).
3. Cuando termine (unos 5-8 min), entra a la ejecución y descarga el artefacto "tumaco-ruta-apk" (zip con app-debug.apk).
4. Pasa el APK al celular, ábrelo y permite "instalar apps de orígenes desconocidos". Acepta el permiso de ubicación.
5. Con internet, en el mapa toca "Plano base OSM" una sola vez: baja calles y barrios de Tumaco y luego todo funciona sin conexión.
Para actualizar la app: reemplaza www/index.html y vuelve a ejecutar el workflow.

Nota: si Windows Defender marca el zip, es un falso positivo de heurística (la app no contiene ejecutables, solo HTML/JS). Puedes revisar el código: www/index.html es texto plano.
